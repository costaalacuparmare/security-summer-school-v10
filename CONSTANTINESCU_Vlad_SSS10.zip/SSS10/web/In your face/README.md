### In your face
```
Easy enough, the flag was hidden in a commentary in the source code, coded in base64
```
