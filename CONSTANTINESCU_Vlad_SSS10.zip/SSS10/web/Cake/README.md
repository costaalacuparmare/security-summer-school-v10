### Cake
```
It wasn't a piece of cake, but checking the network traffic of the side and noticing the cookie's name as flag, I
tried modifying the cookie using the given hint and voila, the cookie response was the flag
```
