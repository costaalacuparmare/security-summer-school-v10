### Welcome
```
The flag was divided in four parts, spread around the source files. First part in the first comment in the
css file, the second one being white text in the html file, the third one in the js file, and the fourth one in a png/
If combined, the first FFFs gave it away as being encrypted with caesar's cipher, and i decoded it.
```
