### Mirror-me
``` 
Using gdb (pwndgb) and parsing line by line I noticed that the required values are two numbers that multiplied,
must result the value 906609. Using nc, i connected to the given server and inputed the values, thus accesing
a shell where i could find the flag
```
