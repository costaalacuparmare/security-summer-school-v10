### One-by-one
```
Using the nm utility to see the symbols and notices that there a lot of parts in the data section
and printed them using gdb
```
