### Pinpoint
```
Using nm I noticed a named variable v. Running the program, are asked to input an address and a number.
Making changed to the v variable, you get acces to a shell. Using nc to connect to the ip and port given, i retrieved
the flag
```
