### Black Hole 

```
Used 'break' in gdb (pwdgb) to check the used functions in the exec and found the fread function.
Entering it i noticed the flag in the stack
```
